using System;
using System.Linq;

namespace ej9.Data{


    public class Iglesia{
 public int IglesiaId{get; set;}
public string Sexo {get; set;}
public string Apellidos {get; set;}
public string Nombres{get; set;}
public DateTime   FechaNacimiento {get; set;}
 public string Paísnacimiento {get; set;}
public string Ciudadnacimiento {get; set;}
public string Paísactual {get; set;}
public string Ciudadactual {get; set;}
public string  Dirección {get; set;}
public int Teléfono {get; set;}
public int Celular {get; set;}
public string Correoelectrónico {get; set;}
public string Tipoidenti {get; set;}
public string Documentoidentidad {get; set;}


    
}
}